package com.kelompok.rasul;

import androidx.appcompat.app.AppCompatActivity;

import android.net.Uri;
import android.view.View;
import android.os.Bundle;
import android.content.Intent;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    Button intentIbr, intentIsa, intentMuh, intentMus, intentNuh;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        intentIbr = (Button) findViewById(R.id.Implicit_Intent_ibrahim);
        intentIsa = (Button) findViewById(R.id.Implicit_Intent_isa);
        intentMuh = (Button) findViewById(R.id.Implicit_Intent_muhammad);
        intentMus = (Button) findViewById(R.id.Implicit_Intent_musa);
        intentNuh = (Button) findViewById(R.id.Implicit_Intent_nuh);

        //implement onClick event for Implicit Intent

        intentIbr.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(Intent.ACTION_VIEW);
                intent.setData(Uri.parse("https://id.wikipedia.org/wiki/Ibrahim.com"));
                startActivity(intent);
            }
        });

        intentIsa.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(Intent.ACTION_VIEW);
                intent.setData(Uri.parse("https://id.wikipedia.org/wiki/Isa.com"));
                startActivity(intent);
            }
        });

        intentMuh.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(Intent.ACTION_VIEW);
                intent.setData(Uri.parse("https://id.wikipedia.org/wiki/Muhammad.com"));
                startActivity(intent);
            }
        });
        intentMus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(Intent.ACTION_VIEW);
                intent.setData(Uri.parse("https://id.wikipedia.org/wiki/Musa.com"));
                startActivity(intent);
            }
        });
        intentNuh.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(Intent.ACTION_VIEW);
                intent.setData(Uri.parse("https://id.wikipedia.org/wiki/Nuh.com"));
                startActivity(intent);
            }
        });
    }



    public void bt_nuh(View view) {
        Intent i = new Intent(MainActivity.this,Nuh.class);
        startActivity(i);
    }

    public void bt_ibrahim(View view) {
        Intent i = new Intent(MainActivity.this,Ibrahim.class);
        startActivity(i);
    }

    public void bt_musa(View view) {
        Intent i = new Intent(MainActivity.this,Musa.class);
        startActivity(i);
    }

    public void bt_isa(View view) {
        Intent i = new Intent(MainActivity.this,Isa.class);
        startActivity(i);
    }
    public void bt_muhammad(View view) {
        Intent i = new Intent(MainActivity.this,Muhammad.class);
        startActivity(i);
    }
}